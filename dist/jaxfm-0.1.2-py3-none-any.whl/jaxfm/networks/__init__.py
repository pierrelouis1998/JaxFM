from jaxfm.networks.mlp import MLP

__all__ = ["MLP"]
